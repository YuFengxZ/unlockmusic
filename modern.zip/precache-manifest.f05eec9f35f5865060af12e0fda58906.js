self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "193b5f903c67da55f45d",
    "url": "css/app.30b45c25.css"
  },
  {
    "revision": "8d57f12e8cc04b462e3f",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "50023a090d7749f0352d744c59b52dcc",
    "url": "index.html"
  },
  {
    "revision": "648c12bb1251505519f5d09e2cdae861",
    "url": "js/0-legacy.75478485.worker.js"
  },
  {
    "revision": "193b5f903c67da55f45d",
    "url": "js/app-legacy.8b3b0c58.js"
  },
  {
    "revision": "8d57f12e8cc04b462e3f",
    "url": "js/chunk-vendors-legacy.e75bd7b3.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);